#!/bin/sh
 export LD_LIBRARY_PATH=`pwd`/Qt_Libs
 export QT_QPA_PLATFORM_PLUGIN_PATH=`pwd`/Qt_Libs
 ./NumConverter